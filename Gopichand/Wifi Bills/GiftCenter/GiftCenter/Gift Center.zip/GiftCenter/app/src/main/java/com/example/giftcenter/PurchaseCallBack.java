package com.example.giftcenter;

public interface PurchaseCallBack {
    void update();
    void swapToRedeem();
}
