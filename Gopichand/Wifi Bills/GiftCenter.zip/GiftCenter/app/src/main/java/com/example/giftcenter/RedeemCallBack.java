package com.example.giftcenter;

public interface RedeemCallBack {
    void update();
    void swapToPurchase();
}
